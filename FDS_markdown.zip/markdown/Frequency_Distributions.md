# PERFORMING FREQUENCY DISTRIBUTIONS OVER MULTIPLE DATA

## (i) Ungrouped frequency distributions

**Create the DataFrame and build the frequency table**

```python
import pandas as pd
df = pd.DataFrame({
    'ID': ['1', '2', '3', '4', '5', '6'],
    'Product_name': ['alex', 'bob', 'cathy', 'doge', 'eric', 'fred'],
    'State': ['Taminadu', 'Tamilnadu', 'Taminadu', 'Andra', 'Madhyapradesh', 'Orissa'],
    'Salescount': ['1000', '2000', '3500', '450', '560', '250']})
print(df)
print(df['State'].value_counts())
```

Output:

```
  ID Product_name          State Salescount
0  1         alex       Taminadu       1000
1  2          bob      Tamilnadu       2000
2  3        cathy       Taminadu       3500
3  4         doge          Andra        450
4  5         eric  Madhyapradesh        560
5  6         fred         Orissa        250
State
Taminadu         2
Tamilnadu        1
Andra            1
Madhyapradesh    1
Orissa           1
Name: count, dtype: int64
```

**Histogram of the State column**

```python
import matplotlib.pyplot as plt
plt.hist(df['State'])
plt.ylabel('Frequency count')
plt.xlabel('Data')
plt.title('My histogram')
plt.show()
```

![Histogram of the State column](graphs/Frequency_Distributions_s2_0.png)

## b) Grouped frequency distribution

**Group by ID and plot the maximum Salescount**

```python
import pandas as pd
import matplotlib.pyplot as plt
df = pd.DataFrame({
    'ID': ['1', '1', '2', '3', '4'],
    'Product_Name': ['CS', 'SE', 'SE', 'SE', 'CS'],
    'State': [60, 70, 59, 51, 80],
    'Salescount': [20, 21, 20, 22, 23]})
print(df)
df.groupby('ID')['Salescount'].max().plot(kind='bar', legend=True)
plt.show()
```

Output:

```
  ID Product_Name  State  Salescount
0  1           CS     60          20
1  1           SE     70          21
2  2           SE     59          20
3  3           SE     51          22
4  4           CS     80          23
```

![Group by ID and plot the maximum Salescount](graphs/Frequency_Distributions_s3_0.png)

## c) Cumulative frequency distributions

**Cumulative frequency using scipy.stats.cumfreq**

```python
from scipy import stats
import numpy as np
Salescount = [20, 21, 20, 22, 23]
print("Array element : ", Salescount, "\n")
a, b, c, d = stats.cumfreq(Salescount, numbins=4)
print("cumulative frequency : ", a)
print("Lower Limit : ", b)
print("bin size : ", c)
print("extra-points : ", d)
```

Output:

```
Array element :  [20, 21, 20, 22, 23] 

cumulative frequency :  [2. 3. 4. 5.]
Lower Limit :  19.5
bin size :  1.0
extra-points :  0
```

**Cumulative frequency plot**

```python
x = b + np.arange(len(a)) * c
plt.plot(x, a, marker='o')
plt.title("Cumulative frequency"); plt.xlabel("Salescount"); plt.ylabel("Cumulative count"); plt.grid(True)
plt.show()
```

![Cumulative frequency plot](graphs/Frequency_Distributions_s5_0.png)

## d) Relative frequency distributions

**Relative frequency histogram**

```python
from scipy import stats
import numpy as np
import matplotlib.pyplot as plt
Salescount = [20, 21, 20, 22, 23]
a, b, c, d = stats.cumfreq(Salescount, numbins=4)
print("cumulative frequency : ", a)
print("relative cumulative frequency : ", a / len(Salescount))
fig = plt.figure()
ax = fig.add_subplot(111)
ax.hist(Salescount, edgecolor='black', weights=np.ones_like(Salescount) / len(Salescount))
ax.set_xlabel("Salescount"); ax.set_ylabel("Relative frequency"); ax.set_title("Relative frequency histogram")
plt.show()
```

Output:

```
cumulative frequency :  [2. 3. 4. 5.]
relative cumulative frequency :  [0.4 0.6 0.8 1. ]
```

![Relative frequency histogram](graphs/Frequency_Distributions_s6_0.png)
