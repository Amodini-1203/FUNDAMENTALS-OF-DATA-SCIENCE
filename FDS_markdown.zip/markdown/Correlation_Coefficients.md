# CREATION OF VARIOUS CORRELATION COEFFICIENT FUNCTIONS IN PYTHON

## a) Plot the correlation plot on dataset and visualize an overview of relationships among data (Iris)

**Read the data**

```python
import pandas as pd
df = pd.read_csv("Iris.csv")
print(df.head())
print(df.shape)
print(df.isnull().sum())
```

Output:

```
   Id  SepalLengthCm  SepalWidthCm  PetalLengthCm  PetalWidthCm      Species
0   1            5.1           3.5            1.4           0.2  Iris-setosa
1   2            4.9           3.0            1.4           0.2  Iris-setosa
2   3            4.7           3.2            1.3           0.2  Iris-setosa
3   4            4.6           3.1            1.5           0.2  Iris-setosa
4   5            5.0           3.6            1.4           0.2  Iris-setosa
(150, 6)
Id               0
SepalLengthCm    0
SepalWidthCm     0
PetalLengthCm    0
PetalWidthCm     0
Species          0
dtype: int64
```

**Unique species and counts**

```python
data = df.drop_duplicates(subset="Species")
print(data)
print(df.value_counts("Species"))
```

Output:

```
      Id  SepalLengthCm  SepalWidthCm  PetalLengthCm  PetalWidthCm          Species
0      1            5.1           3.5            1.4           0.2      Iris-setosa
50    51            7.0           3.2            4.7           1.4  Iris-versicolor
100  101            6.3           3.3            6.0           2.5   Iris-virginica
Species
Iris-setosa        50
Iris-versicolor    50
Iris-virginica     50
Name: count, dtype: int64
```

**Count plot of Species**

```python
import seaborn as sns
import matplotlib.pyplot as plt
sns.countplot(x='Species', data=df)
plt.show()
```

![Count plot of Species](graphs/Correlation_Coefficients_s3_0.png)

**Pair plot to show relationships between the variables**

```python
sns.pairplot(df.drop(columns='Id'), hue='Species', height=2.2)
plt.show()
```

![Pair plot to show relationships between the variables](graphs/Correlation_Coefficients_s4_0.png)

## b) Find the correlation matrix

**Pearson correlation matrix with dataframe.corr()**

```python
num = df.select_dtypes('number')
print(num.corr(method='pearson'))
```

Output:

```
                     Id  SepalLengthCm  SepalWidthCm  PetalLengthCm  PetalWidthCm
Id             1.000000       0.716676     -0.402301       0.882637      0.900027
SepalLengthCm  0.716676       1.000000     -0.117570       0.871754      0.817941
SepalWidthCm  -0.402301      -0.117570      1.000000      -0.428440     -0.366126
PetalLengthCm  0.882637       0.871754     -0.428440       1.000000      0.962865
PetalWidthCm   0.900027       0.817941     -0.366126       0.962865      1.000000
```

**Heatmap of the correlation matrix**

```python
corr = num.corr()
plt.figure(figsize=(6, 4.5))
sns.heatmap(corr, annot=True, cmap='coolwarm', xticklabels=corr.columns.values, yticklabels=corr.columns.values)
plt.title("Correlation matrix (Pearson)")
plt.show()
```

![Heatmap of the correlation matrix](graphs/Correlation_Coefficients_s6_0.png)

**Other correlation coefficient functions: Spearman and Kendall**

```python
print("Spearman:")
print(num.drop(columns='Id').corr(method='spearman').round(3))
print("Kendall:")
print(num.drop(columns='Id').corr(method='kendall').round(3))
from scipy.stats import pearsonr
r, p = pearsonr(df['PetalLengthCm'], df['PetalWidthCm'])
print("pearsonr(PetalLengthCm, PetalWidthCm) = %.4f, p-value = %.3g" % (r, p))
```

Output:

```
Spearman:
               SepalLengthCm  SepalWidthCm  PetalLengthCm  PetalWidthCm
SepalLengthCm          1.000        -0.167          0.882         0.834
SepalWidthCm          -0.167         1.000         -0.310        -0.289
PetalLengthCm          0.882        -0.310          1.000         0.938
PetalWidthCm           0.834        -0.289          0.938         1.000
Kendall:
               SepalLengthCm  SepalWidthCm  PetalLengthCm  PetalWidthCm
SepalLengthCm          1.000        -0.077          0.719         0.655
SepalWidthCm          -0.077         1.000         -0.186        -0.157
PetalLengthCm          0.719        -0.186          1.000         0.807
PetalWidthCm           0.655        -0.157          0.807         1.000
pearsonr(PetalLengthCm, PetalWidthCm) = 0.9629, p-value = 4.68e-86
```

## c) Analysis of variance (ANOVA), when data have categorical variables - Iris

**Mean sepal width per species and one-way ANOVA**

```python
from scipy.stats import f_oneway
print(df['SepalWidthCm'].groupby(df['Species']).mean())
groups = [g['SepalWidthCm'].values for _, g in df.groupby('Species')]
f, p = f_oneway(*groups)
print("F-statistic = %.3f, p-value = %.3g" % (f, p))
print(df.drop(columns='Species').mean())
```

Output:

```
Species
Iris-setosa        3.428
Iris-versicolor    2.770
Iris-virginica     2.974
Name: SepalWidthCm, dtype: float64
F-statistic = 49.160, p-value = 4.49e-17
Id               75.500000
SepalLengthCm     5.843333
SepalWidthCm      3.057333
PetalLengthCm     3.758000
PetalWidthCm      1.199333
dtype: float64
```

**Box plot of sepal width by species**

```python
sns.boxplot(x='Species', y='SepalWidthCm', data=df)
plt.title("Sepal width by species")
plt.show()
```

![Box plot of sepal width by species](graphs/Correlation_Coefficients_s9_0.png)
