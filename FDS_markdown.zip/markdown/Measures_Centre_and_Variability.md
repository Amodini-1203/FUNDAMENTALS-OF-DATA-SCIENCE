# CALCULATION OF MEASURES OF CENTRE AND VARIABILITY FOR THE GIVEN DATA

## Measures of centre: mean, median and mode

**Create the DataFrame**

```python
import pandas as pd
df = pd.DataFrame({
    'ID': ['1', '2', '3', '4', '5'],
    'Name': ['CS', 'SE', 'SE', 'SE', 'CS'],
    'Department': ['cse', 'eee', 'ece', 'it', 'AI'],
    'Year': ['3', '2', '1', '4', '1'],
    'Subject_Marks': [72, 73, 72, 72, 73]})
print(df)
dataMatrix = {"Subject_Marks": [72, 73, 72, 72, 73]}
dataFrame = pd.DataFrame(data=dataMatrix)
print("DataFrame:")
print(dataFrame)
```

Output:

```
  ID Name Department Year  Subject_Marks
0  1   CS        cse    3             72
1  2   SE        eee    2             73
2  3   SE        ece    1             72
3  4   SE         it    4             72
4  5   CS         AI    1             73
DataFrame:
   Subject_Marks
0             72
1             73
2             72
3             72
4             73
```

**Mean (column-wise and row-wise)**

```python
print("Mean:Computed column-wise:")
print(dataFrame.mean())
print("Mean:Computed row-wise:")
print(dataFrame.mean(axis=1))
```

Output:

```
Mean:Computed column-wise:
Subject_Marks    72.4
dtype: float64
Mean:Computed row-wise:
0    72.0
1    73.0
2    72.0
3    72.0
4    73.0
dtype: float64
```

**Median (column-wise and row-wise)**

```python
print("Median:Computed column-wise:")
print(dataFrame.median())
print("Median:Computed row-wise:")
print(dataFrame.median(axis=1))
```

Output:

```
Median:Computed column-wise:
Subject_Marks    72.0
dtype: float64
Median:Computed row-wise:
0    72.0
1    73.0
2    72.0
3    72.0
4    73.0
dtype: float64
```

**Mode (column-wise and row-wise)**

```python
print("Mode:Computed column-wise:")
print(dataFrame.mode())
print("Mode:Computed row-wise:")
print(dataFrame.mode(axis=1))
```

Output:

```
Mode:Computed column-wise:
   Subject_Marks
0             72
Mode:Computed row-wise:
    0
0  72
1  73
2  72
3  72
4  73
```

## Measures of variability: range, standard deviation, variance, IQR

**Dataset information**

```python
import pandas as pd
import numpy as np
print(df.shape)
print(df.info())
```

Output:

```
(5, 5)
<class 'pandas.DataFrame'>
RangeIndex: 5 entries, 0 to 4
Data columns (total 5 columns):
 #   Column         Non-Null Count  Dtype
---  ------         --------------  -----
 0   ID             5 non-null      str  
 1   Name           5 non-null      str  
 2   Department     5 non-null      str  
 3   Year           5 non-null      str  
 4   Subject_Marks  5 non-null      int64
dtypes: int64(1), str(4)
memory usage: 332.0 bytes
None
```

**Range, standard deviation, variance, interquartile range and describe()**

```python
from scipy.stats import iqr
marks = dataFrame['Subject_Marks']
print("Range:", [marks.min(), marks.max()], " (max - min =", marks.max() - marks.min(), ")")
print("Standard Deviation:")
print(dataFrame.std())
print("Variance:")
print(dataFrame.var())
print("Interquartile Range:", iqr(marks))
print(dataFrame.describe(include='all'))
```

Output:

```
Range: [np.int64(72), np.int64(73)]  (max - min = 1 )
Standard Deviation:
Subject_Marks    0.547723
dtype: float64
Variance:
Subject_Marks    0.3
dtype: float64
Interquartile Range: 1.0
       Subject_Marks
count       5.000000
mean       72.400000
std         0.547723
min        72.000000
25%        72.000000
50%        72.000000
75%        73.000000
max        73.000000
```

**Visualising centre and spread with a box plot / histogram**

```python
import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 2, figsize=(9, 3.2))
ax[0].boxplot(marks, vert=False); ax[0].set_title("Box plot of Subject_Marks")
ax[1].hist(marks, bins=[71.5, 72.5, 73.5], edgecolor='black')
ax[1].axvline(marks.mean(), color='red', linestyle='--', label='mean = %.1f' % marks.mean())
ax[1].legend(); ax[1].set_title("Histogram of Subject_Marks")
plt.show()
```

![Visualising centre and spread with a box plot / histogram](graphs/Measures_Centre_and_Variability_s7_0.png)
