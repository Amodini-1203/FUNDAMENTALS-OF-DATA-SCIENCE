# CREATION AND VISUALIZATION OF DATA SETS USING PANDAS DATA FRAMES

## a) Create Pandas Series and DataFrame from various inputs

**Creating a simple Series**

```python
import pandas as pd
author = ['Jitender', 'Purnima', 'Arpit', 'Jyoti']
auth_series = pd.Series(author)
print(auth_series)
```

Output:

```
0    Jitender
1     Purnima
2       Arpit
3       Jyoti
dtype: str
```

**Add series externally in a DataFrame**

```python
import pandas as pd
author = ['Jitender', 'Purnima', 'Arpit', 'Jyoti']
article = [210, 211, 114, 178]
auth_series = pd.Series(author)
article_series = pd.Series(article)
frame = {'Author': auth_series, 'Article': article_series}
result = pd.DataFrame(frame)
age = [21, 21, 24, 23]
result['Age'] = pd.Series(age)
print(result)
```

Output:

```
     Author  Article  Age
0  Jitender      210   21
1   Purnima      211   21
2     Arpit      114   24
3     Jyoti      178   23
```

**Visualising the DataFrame**

```python
import matplotlib.pyplot as plt
result.plot(x='Author', y='Article', kind='bar', color='teal', legend=False)
plt.title("Articles written per author"); plt.ylabel("Articles"); plt.xticks(rotation=0)
plt.show()
```

![Visualising the DataFrame](graphs/Pandas_DataFrames_s3_0.png)

## b) Import a CSV file to a Pandas DataFrame and perform the following operations

**Import a CSV file (winequality-red.csv, ';' separated)**

```python
import pandas as pd
df = pd.read_csv('winequality-red.csv', sep=';')
print(df)
```

Output:

```
      fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  \
0               7.4              0.70         0.00             1.9      0.076   
1               7.8              0.88         0.00             2.6      0.098   
2               7.3              0.45         0.07             1.2      0.159   
3              10.3              0.53         0.41             2.8      0.067   
4               7.8              0.63         0.48             2.5      0.066   
...             ...               ...          ...             ...        ...   
1594            9.5              0.28         0.30             2.9      0.052   
1595            8.1              0.60         0.15             1.6      0.106   
1596           10.2              0.53         0.77             1.6      0.012   
1597            6.8              0.87         0.00             2.8      0.060   
1598            8.9              0.48         0.16             2.2      0.035   

      free sulfur dioxide  total sulfur dioxide  density    pH  sulphates  alcohol  quality  
0                    11.0                  34.0  0.99780  3.51       0.56      9.4        5  
1                    25.0                  67.0  0.99680  3.20       0.68      9.8        5  
2                    10.0                  60.0  0.99769  3.19       0.75     11.2        7  
3                    15.0                  57.0  0.99783  3.49       0.67     11.4        7  
4                    10.0                  32.0  0.99468  2.98       0.33      8.4        3  
...                   ...                   ...      ...   ...        ...      ...      ...  
1594                 15.0                  83.0  0.99608  3.40       0.51     10.8        5  
1595                 18.0                  19.0  0.99467  3.35       0.47     10.9        6  
1596                 10.0                   6.0  0.99399  3.47       0.62     10.7        7  
1597                 11.0                  42.0  0.99353  3.68       0.85     10.7        5  
1598                  8.0                  35.0  1.00005  3.27       0.52     12.1        6  

[1599 rows x 12 columns]
```

**Visualize the first and last 10 records**

```python
print("First 10 rows of the DataFrame:")
print(df.head(10))
print("\nLast 10 rows of the DataFrame:")
print(df.tail(10))
```

Output:

```
First 10 rows of the DataFrame:
   fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  free sulfur dioxide  \
0            7.4              0.70         0.00             1.9      0.076                 11.0   
1            7.8              0.88         0.00             2.6      0.098                 25.0   
2            7.3              0.45         0.07             1.2      0.159                 10.0   
3           10.3              0.53         0.41             2.8      0.067                 15.0   
4            7.8              0.63         0.48             2.5      0.066                 10.0   
5           10.2              0.53         0.09             2.6      0.012                 12.0   
6            9.0              0.71         0.27             4.1      0.085                 17.0   
7            7.7              0.45         0.01             4.1      0.117                 11.0   
8            9.1              0.29         0.24             1.8      0.125                 11.0   
9            8.8              0.89         0.43             2.5      0.092                  5.0   

   total sulfur dioxide  density    pH  sulphates  alcohol  quality  
0                  34.0  0.99780  3.51       0.56      9.4        5  
1                  67.0  0.99680  3.20       0.68      9.8        5  
2                  60.0  0.99769  3.19       0.75     11.2        7  
3                  57.0  0.99783  3.49       0.67     11.4        7  
4                  32.0  0.99468  2.98       0.33      8.4        3  
5                   6.0  0.99494  3.27       0.63      9.0        5  
6                   6.0  0.99696  3.53       0.83     10.5        7  
7                 143.0  0.99487  3.42       0.53     10.1        6  
8                  93.0  0.99704  3.26       0.82     10.4        6  
9                  89.0  0.99949  3.02       0.69      9.5        5  

Last 10 rows of the DataFrame:
      fixed acidity  volatile acidity  citric acid  residual sugar  chlorides  \
1589            8.3              0.80         0.30             3.0      0.074   
1590           11.7              0.26         0.26             2.3      0.075   
1591            9.3              0.43         0.26             3.8      0.083   
1592            5.4              0.61         0.25             2.2      0.112   
1593            4.6              0.52         0.20             2.3      0.062   
1594            9.5              0.28         0.30             2.9      0.052   
1595            8.1              0.60         0.15             1.6      0.106   
1596           10.2              0.53         0.77             1.6      0.012   
1597            6.8              0.87         0.00             2.8      0.060   
1598            8.9              0.48         0.16             2.2      0.035   

      free sulfur dioxide  total sulfur dioxide  density    pH  sulphates  alcohol  quality  
1589                 42.0                  10.0  0.99739  3.61       0.67      9.9        5  
1590                 12.0                  22.0  0.99713  3.36       0.72      8.9        4  
1591                  1.0                  55.0  0.99792  3.50       0.58      8.9        4  
1592                  1.0                   6.0  0.99730  3.40       0.89     10.2        5  
1593                 31.0                  43.0  0.99759  3.51       0.67      9.6        5  
1594                 15.0                  83.0  0.99608  3.40       0.51     10.8        5  
1595                 18.0                  19.0  0.99467  3.35       0.47     10.9        6  
1596                 10.0                   6.0  0.99399  3.47       0.62     10.7        7  
1597                 11.0                  42.0  0.99353  3.68       0.85     10.7        5  
1598                  8.0                  35.0  1.00005  3.27       0.52     12.1        6  
```

**Get the shape, index and column details**

```python
shape = df.shape
print('DataFrame Shape :', shape)
print('Number of rows :', shape[0])
print('Number of columns :', shape[1])
print('Index :', df.index)
print('Columns :', list(df.columns))
```

Output:

```
DataFrame Shape : (1599, 12)
Number of rows : 1599
Number of columns : 12
Index : RangeIndex(start=0, stop=1599, step=1)
Columns : ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol', 'quality']
```

**Select the records (rows) based on conditions - employees.csv**

```python
df = pd.read_csv('employees.csv')
print(df.head())
```

Output:

```
  First Name  Gender Start Date Last Login Time  Salary  Bonus % Senior Management  \
0    Douglas    Male   8/6/1993        12:42 PM   97308    6.945              True   
1     Thomas    Male  3/31/1996         6:53 AM   61933    4.170              True   
2      Maria  Female  4/23/1993        11:17 AM  130590   11.858             False   
3      Jerry    Male   3/4/2005         1:00 PM  138705    9.340              True   
4      Larry    Male  1/24/1998         4:47 PM  101004    1.389              True   

              Team  
0        Marketing  
1              NaN  
2          Finance  
3          Finance  
4  Client Services  
```

**Rows with Bonus % > 5**

```python
new_df = df[df['Bonus %'] > 5]
print(new_df.head(8))
print("Rows selected:", len(new_df))
```

Output:

```
   First Name  Gender  Start Date Last Login Time  Salary  Bonus % Senior Management  \
0     Douglas    Male    8/6/1993        12:42 PM   97308    6.945              True   
2       Maria  Female   4/23/1993        11:17 AM  130590   11.858             False   
3       Jerry    Male    3/4/2005         1:00 PM  138705    9.340              True   
5     Brandon    Male  10/20/1995        11:49 PM  127963    6.183               NaN   
6     Douglas  Female    7/4/2009         3:32 PM  148888    7.852              True   
7       Henry    Male  12/26/1994         6:10 PM   85016   14.044              True   
9     Michael  Female  11/16/1986        11:32 AM   41400   15.192             False   
10     Louise  Female   8/18/2000         9:55 AM   81204    7.440             False   

               Team  
0         Marketing  
2           Finance  
3           Finance  
5       Engineering  
6             Sales  
7         Marketing  
9   Client Services  
10            Sales  
Rows selected: 785
```

**Rows with Salary > 60000 using loc**

```python
new_df = df.loc[df['Salary'] > 60000]
print(new_df.head(8))
print("Rows selected:", len(new_df))
```

Output:

```
  First Name  Gender  Start Date Last Login Time  Salary  Bonus % Senior Management  \
0    Douglas    Male    8/6/1993        12:42 PM   97308    6.945              True   
1     Thomas    Male   3/31/1996         6:53 AM   61933    4.170              True   
2      Maria  Female   4/23/1993        11:17 AM  130590   11.858             False   
3      Jerry    Male    3/4/2005         1:00 PM  138705    9.340              True   
4      Larry    Male   1/24/1998         4:47 PM  101004    1.389              True   
5    Brandon    Male  10/20/1995        11:49 PM  127963    6.183               NaN   
6    Douglas  Female    7/4/2009         3:32 PM  148888    7.852              True   
7      Henry    Male  12/26/1994         6:10 PM   85016   14.044              True   

              Team  
0        Marketing  
1              NaN  
2          Finance  
3          Finance  
4  Client Services  
5      Engineering  
6            Sales  
7        Marketing  
Rows selected: 798
```

**Delete rows / columns based on conditions**

```python
smaller = df.drop(df[df['Salary'] < 40000].index)       # delete rows
print("Rows before:", len(df), " after deleting Salary < 40000:", len(smaller))
no_gender = df.drop(columns=['Gender'])                    # delete a column
print("Columns after drop:", list(no_gender.columns))
```

Output:

```
Rows before: 1000  after deleting Salary < 40000: 956
Columns after drop: ['First Name', 'Start Date', 'Last Login Time', 'Salary', 'Bonus %', 'Senior Management', 'Team']
```

**Perform ranking and sorting operations**

```python
df["Rank"] = df["Salary"].rank()
print(df.head())
df.sort_values("Salary", inplace=True)
print(df.head())
```

Output:

```
  First Name  Gender Start Date Last Login Time  Salary  Bonus % Senior Management  \
0    Douglas    Male   8/6/1993        12:42 PM   97308    6.945              True   
1     Thomas    Male  3/31/1996         6:53 AM   61933    4.170              True   
2      Maria  Female  4/23/1993        11:17 AM  130590   11.858             False   
3      Jerry    Male   3/4/2005         1:00 PM  138705    9.340              True   
4      Larry    Male  1/24/1998         4:47 PM  101004    1.389              True   

              Team   Rank  
0        Marketing  555.0  
1              NaN  220.0  
2          Finance  849.0  
3          Finance  911.0  
4  Client Services  588.0  
      First Name  Gender  Start Date Last Login Time  Salary  Bonus % Senior Management  \
155  Christopher    Male   5/11/2011         2:28 AM   35072   10.065             False   
561        James  Female   9/28/2012         5:04 AM   35163   19.240              True   
852      Frances  Female  12/22/2005         3:02 PM   35292   19.434              True   
650      Douglas    Male   3/26/2004         7:06 PM   35496    3.477              True   
673     Jonathan  Female    5/6/1997         5:18 PM   35590    1.844               NaN   

                Team  Rank  
155              NaN   1.0  
561  Human Resources   2.0  
852              NaN   3.0  
650        Marketing   4.0  
673              NaN   5.0  
```

**Do required statistical operations on the given columns**

```python
mean = df['Salary'].mean()
print(mean)
median = df['Bonus %'].median()
print(median)
```

Output:

```
91974.729
9.948
```

**Find the count and uniqueness of the given categorical values**

```python
count = df['Bonus %'].count()
print(count)
s = df['Salary'].value_counts()
print("Number of unique salaries:", df['Salary'].nunique())
print(s.head())
print("\nTeam value counts:")
print(df['Team'].value_counts())
print("\nUnique teams:", df['Team'].unique())
```

Output:

```
1000
Number of unique salaries: 995
Salary
70692     2
80330     2
97672     2
119470    2
131215    2
Name: count, dtype: int64

Team value counts:
Team
Product                 107
Finance                 104
Human Resources         103
Client Services         102
Marketing                95
Legal                    95
Distribution             91
Business Development     89
Sales                    87
Engineering              86
Name: count, dtype: int64

Unique teams: <StringArray>
[                   nan,      'Human Resources',            'Marketing',                'Legal',
         'Distribution',              'Product',      'Client Services', 'Business Development',
              'Finance',          'Engineering',                'Sales']
Length: 11, dtype: str
```

**Rename single / multiple columns**

```python
df.rename(columns={'Team': 'Team_name'}, inplace=True)
print(df.head(3))
df.rename(columns={'Salary': 'Salary_INR', 'Bonus %': 'Bonus_Pct'}, inplace=True)
print(list(df.columns))
```

Output:

```
      First Name  Gender  Start Date Last Login Time  Salary  Bonus % Senior Management  \
155  Christopher    Male   5/11/2011         2:28 AM   35072   10.065             False   
561        James  Female   9/28/2012         5:04 AM   35163   19.240              True   
852      Frances  Female  12/22/2005         3:02 PM   35292   19.434              True   

           Team_name  Rank  
155              NaN   1.0  
561  Human Resources   2.0  
852              NaN   3.0  
['First Name', 'Gender', 'Start Date', 'Last Login Time', 'Salary_INR', 'Bonus_Pct', 'Senior Management', 'Team_name', 'Rank']
```

**Visualisation: wine quality distribution and salary histogram**

```python
import matplotlib.pyplot as plt
wine = pd.read_csv('winequality-red.csv', sep=';')
fig, ax = plt.subplots(1, 2, figsize=(10, 3.6))
wine['quality'].value_counts().sort_index().plot(kind='bar', ax=ax[0], color='firebrick')
ax[0].set_title("Wine quality counts"); ax[0].set_xlabel("quality"); ax[0].set_ylabel("count")
df['Salary_INR'].plot(kind='hist', bins=20, ax=ax[1], color='steelblue', edgecolor='white')
ax[1].set_title("Salary distribution"); ax[1].set_xlabel("Salary")
plt.show()
```

![Visualisation: wine quality distribution and salary histogram](graphs/Pandas_DataFrames_s15_0.png)
